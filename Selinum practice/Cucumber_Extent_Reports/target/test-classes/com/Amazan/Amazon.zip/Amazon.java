package com.Amazan;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.idealized.Javascript;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Amazon {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.amazon.in/s?k=-amazon&hvadid=72499124504037&hvbmt=be&hvdev=c&hvqmt=e&tag=msndeskstdin-21&ref=pd_sl_5fksc5jb1x_e");
	driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		WebElement e=driver.findElement(By.id("twotabsearchtextbox"));
	e.clear();
	e.sendKeys("redmi mobie");
	System.out.println(driver.getTitle());
	driver.findElement(By.xpath("//*[@*='redmi movie mobile']")).click();
	List<WebElement> ele=driver.findElements(By.xpath("//*[contains(text(),'Redmi Note ')]"));
	System.out.println(ele.size());
	JavascriptExecutor jec=(JavascriptExecutor)driver;
	//jec.executeScript("window.scrollBy(30,400);");
	for (WebElement web : ele) {
		web.click();
		Thread.sleep(3000);
		String main=driver.getWindowHandle();
		Set<String> all=driver.getWindowHandles();
	   ArrayList<String> id=new ArrayList<>(all);
	   int lastid=id.size();
	   driver.switchTo().window(id.get(lastid-1));
	   driver.findElement(By.xpath("//*[@*='submit.add-to-cart']")).click();
	   jec.executeScript("window.scrollBy(30,400);");
	   Thread.sleep(3000);
	   driver.navigate().back();
		driver.close();
		driver.switchTo().window(main);
		
	}
	}

}
